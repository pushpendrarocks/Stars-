# Don't Remove Credit Tg - @VJ_Botz
# Subscribe YouTube Channel For Amazing Bot https://youtube.com/@Tech_VJ
# Ask Doubt on telegram @KingVJ01

from os import environ

API_ID = int(environ.get("API_ID", "22595991"))
API_HASH = environ.get("API_HASH", "cbbdfbb7b0e1771ae49d8a3efa8da2ad")
BOT_TOKEN = environ.get("BOT_TOKEN", "")
